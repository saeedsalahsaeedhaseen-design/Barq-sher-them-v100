package com.example.util

import java.nio.charset.StandardCharsets

/**
 * Self-contained ISO/IEC 18004 QR Code Matrix Generator (Byte mode, Error Correction Level L/M)
 * Supports versions 1..6 (up to 134 bytes of UTF-8 payload, plenty for P2P URLs & PeerJS codes)
 * without requiring external binary barcode dependencies.
 */
object QrCodeGenerator {

    fun encodeToMatrix(content: String): Array<BooleanArray> {
        val dataBytes = content.toByteArray(StandardCharsets.UTF_8)
        // Pick smallest QR version (EC Level L) that fits dataBytes
        // Version capacities in Byte mode (EC Level L):
        // V1: 17, V2: 32, V3: 53, V4: 78, V5: 106, V6: 134
        val version = when {
            dataBytes.size <= 17 -> 1
            dataBytes.size <= 32 -> 2
            dataBytes.size <= 53 -> 3
            dataBytes.size <= 78 -> 4
            dataBytes.size <= 106 -> 5
            else -> 6
        }
        val clippedBytes = if (dataBytes.size > 134) dataBytes.copyOf(134) else dataBytes

        val totalCodewords = intArrayOf(0, 26, 44, 70, 100, 134, 172)[version]
        val ecCodewordsPerBlock = intArrayOf(0, 7, 10, 15, 20, 26, 18)[version]
        val numBlocks = if (version == 6) 2 else 1
        val dataCodewordsTotal = totalCodewords - ecCodewordsPerBlock * numBlocks

        // Build bit stream: Mode 0100 (Byte mode), 8-bit length, data bytes, terminator
        val bits = BooleanArray(dataCodewordsTotal * 8)
        var bitIdx = 0
        fun appendBits(value: Int, length: Int) {
            for (i in length - 1 downTo 0) {
                if (bitIdx < bits.size) {
                    bits[bitIdx++] = ((value ushr i) and 1) != 0
                }
            }
        }

        appendBits(0b0100, 4)
        appendBits(clippedBytes.size, 8)
        for (b in clippedBytes) {
            appendBits(b.toInt() and 0xFF, 8)
        }
        // Terminator up to 4 zero bits
        appendBits(0, minOf(4, bits.size - bitIdx))
        // Pad to byte boundary
        while (bitIdx % 8 != 0 && bitIdx < bits.size) {
            bits[bitIdx++] = false
        }
        // Pad codewords 0xEC, 0x11
        var padToggle = true
        while (bitIdx < bits.size) {
            appendBits(if (padToggle) 0xEC else 0x11, 8)
            padToggle = !padToggle
        }

        val dataWords = IntArray(dataCodewordsTotal)
        for (i in 0 until dataCodewordsTotal) {
            var v = 0
            for (b in 0 until 8) {
                v = (v shl 1) or (if (bits[i * 8 + b]) 1 else 0)
            }
            dataWords[i] = v
        }

        // Split into blocks and compute Reed-Solomon EC codewords
        val finalCodewords = IntArray(totalCodewords)
        if (numBlocks == 1) {
            val ec = computeReedSolomon(dataWords, ecCodewordsPerBlock)
            System.arraycopy(dataWords, 0, finalCodewords, 0, dataWords.size)
            System.arraycopy(ec, 0, finalCodewords, dataWords.size, ec.size)
        } else {
            val blockSize = dataCodewordsTotal / 2
            val block1 = dataWords.copyOfRange(0, blockSize)
            val block2 = dataWords.copyOfRange(blockSize, dataCodewordsTotal)
            val ec1 = computeReedSolomon(block1, ecCodewordsPerBlock)
            val ec2 = computeReedSolomon(block2, ecCodewordsPerBlock)
            var outIdx = 0
            for (i in 0 until blockSize) {
                finalCodewords[outIdx++] = block1[i]
                finalCodewords[outIdx++] = block2[i]
            }
            for (i in 0 until ecCodewordsPerBlock) {
                finalCodewords[outIdx++] = ec1[i]
                finalCodewords[outIdx++] = ec2[i]
            }
        }

        val size = 17 + version * 4
        val modules = Array(size) { BooleanArray(size) }
        val isFunction = Array(size) { BooleanArray(size) }

        fun setFunctionModule(r: Int, c: Int, dark: Boolean) {
            if (r in 0 until size && c in 0 until size) {
                modules[r][c] = dark
                isFunction[r][c] = true
            }
        }

        // Finder patterns + separators
        fun drawFinderPattern(centerR: Int, centerC: Int) {
            for (dy in -4..4) {
                for (dx in -4..4) {
                    val dist = maxOf( kotlin.math.abs(dx), kotlin.math.abs(dy) )
                    val r = centerR + dy
                    val c = centerC + dx
                    if (r in 0 until size && c in 0 until size) {
                        setFunctionModule(r, c, dist != 2 && dist != 4)
                    }
                }
            }
        }

        drawFinderPattern(3, 3)
        drawFinderPattern(3, size - 4)
        drawFinderPattern(size - 4, 3)

        // Timing patterns
        for (i in 0 until size) {
            if (!isFunction[6][i]) setFunctionModule(6, i, i % 2 == 0)
            if (!isFunction[i][6]) setFunctionModule(i, 6, i % 2 == 0)
        }

        // Alignment pattern for versions 2..6
        if (version >= 2) {
            val alignPos = intArrayOf(0, 0, 18, 22, 26, 30, 34)[version]
            for (dy in -2..2) {
                for (dx in -2..2) {
                    val dist = maxOf(kotlin.math.abs(dx), kotlin.math.abs(dy))
                    setFunctionModule(alignPos + dy, alignPos + dx, dist != 1)
                }
            }
        }

        // Reserve format info areas & dark module
        for (i in 0..8) {
            if (i != 6) {
                isFunction[8][i] = true
                isFunction[i][8] = true
            }
        }
        for (i in 0..7) {
            isFunction[8][size - 1 - i] = true
            isFunction[size - 1 - i][8] = true
        }
        setFunctionModule(size - 8, 8, true)

        // Place data bits in zigzag upward/downward columns
        var bitCursor = 0
        val totalBits = finalCodewords.size * 8
        var rightCol = size - 1
        var upward = true
        while (rightCol >= 1) {
            if (rightCol == 6) rightCol -= 1
            for (step in 0 until size) {
                val r = if (upward) size - 1 - step else step
                for (colOffset in 0..1) {
                    val c = rightCol - colOffset
                    if (!isFunction[r][c]) {
                        val dark = if (bitCursor < totalBits) {
                            val word = finalCodewords[bitCursor / 8]
                            val shift = 7 - (bitCursor % 8)
                            bitCursor++
                            ((word ushr shift) and 1) != 0
                        } else {
                            false
                        }
                        // Apply Mask 0: (r + c) % 2 == 0
                        val masked = if ((r + c) % 2 == 0) !dark else dark
                        modules[r][c] = masked
                    }
                }
            }
            upward = !upward
            rightCol -= 2
        }

        // Format information for EC Level L (01) and Mask 0 (000) -> precomputed BCH bits = 0x77C4
        val formatBits = 0x77C4
        fun getFormatBit(idx: Int): Boolean = ((formatBits ushr idx) and 1) != 0

        for (i in 0..5) setFunctionModule(8, i, getFormatBit(i))
        setFunctionModule(8, 7, getFormatBit(6))
        setFunctionModule(8, 8, getFormatBit(7))
        setFunctionModule(7, 8, getFormatBit(8))
        for (i in 9..14) setFunctionModule(14 - i, 8, getFormatBit(i))

        for (i in 0..7) setFunctionModule(size - 1 - i, 8, getFormatBit(i))
        for (i in 8..14) setFunctionModule(8, size - 15 + i, getFormatBit(i))

        return modules
    }

    private fun computeReedSolomon(data: IntArray, degree: Int): IntArray {
        val exp = IntArray(512)
        val log = IntArray(256)
        var x = 1
        for (i in 0 until 255) {
            exp[i] = x
            log[x] = i
            x = x shl 1
            if ((x and 0x100) != 0) x = x xor 0x11D
        }
        for (i in 255 until 512) exp[i] = exp[i - 255]

        fun gfMul(a: Int, b: Int): Int = if (a == 0 || b == 0) 0 else exp[log[a] + log[b]]

        var gen = intArrayOf(1)
        for (i in 0 until degree) {
            val next = IntArray(gen.size + 1)
            val root = exp[i]
            for (j in gen.indices) {
                next[j] = next[j] xor gen[j]
                next[j + 1] = next[j + 1] xor gfMul(gen[j], root)
            }
            gen = next
        }

        val result = IntArray(degree)
        for (b in data) {
            val factor = b xor result[0]
            System.arraycopy(result, 1, result, 0, degree - 1)
            result[degree - 1] = 0
            for (i in 0 until degree) {
                result[i] = result[i] xor gfMul(gen[i + 1], factor)
            }
        }
        return result
    }

    /**
     * Decodes a QR matrix (versions 1..6, Byte mode, Mask 0..7) back into its UTF-8 string payload.
     */
    fun decodeMatrix(modules: Array<BooleanArray>): String? {
        val size = modules.size
        if (size < 21 || (size - 17) % 4 != 0) return null
        val version = (size - 17) / 4
        if (version !in 1..6) return null

        val isFunction = Array(size) { BooleanArray(size) }
        fun markFinder(centerR: Int, centerC: Int) {
            for (dy in -4..4) {
                for (dx in -4..4) {
                    val r = centerR + dy
                    val c = centerC + dx
                    if (r in 0 until size && c in 0 until size) {
                        isFunction[r][c] = true
                    }
                }
            }
        }
        markFinder(3, 3)
        markFinder(3, size - 4)
        markFinder(size - 4, 3)

        for (i in 0 until size) {
            isFunction[6][i] = true
            isFunction[i][6] = true
        }
        if (version >= 2) {
            val alignPos = intArrayOf(0, 0, 18, 22, 26, 30, 34)[version]
            for (dy in -2..2) {
                for (dx in -2..2) {
                    isFunction[alignPos + dy][alignPos + dx] = true
                }
            }
        }
        for (i in 0..8) {
            if (i != 6) {
                isFunction[8][i] = true
                isFunction[i][8] = true
            }
        }
        for (i in 0..7) {
            isFunction[8][size - 1 - i] = true
            isFunction[size - 1 - i][8] = true
        }
        isFunction[size - 8][8] = true

        val totalCodewords = intArrayOf(0, 26, 44, 70, 100, 134, 172)[version]
        val ecCodewordsPerBlock = intArrayOf(0, 7, 10, 15, 20, 26, 18)[version]
        val numBlocks = if (version == 6) 2 else 1
        val dataCodewordsTotal = totalCodewords - ecCodewordsPerBlock * numBlocks

        // Try Mask 0 first (default mask used by encodeToMatrix), then masks 1..7
        for (mask in 0..7) {
            val rawBits = BooleanArray(totalCodewords * 8)
            var bitCursor = 0
            var rightCol = size - 1
            var upward = true
            while (rightCol >= 1) {
                if (rightCol == 6) rightCol -= 1
                for (step in 0 until size) {
                    val r = if (upward) size - 1 - step else step
                    for (colOffset in 0..1) {
                        val c = rightCol - colOffset
                        if (!isFunction[r][c] && bitCursor < rawBits.size) {
                            val masked = modules[r][c]
                            val invert = when (mask) {
                                0 -> (r + c) % 2 == 0
                                1 -> r % 2 == 0
                                2 -> c % 3 == 0
                                3 -> (r + c) % 3 == 0
                                4 -> ((r / 2) + (c / 3)) % 2 == 0
                                5 -> ((r * c) % 2) + ((r * c) % 3) == 0
                                6 -> (((r * c) % 2) + ((r * c) % 3)) % 2 == 0
                                else -> (((r + c) % 2) + ((r * c) % 3)) % 2 == 0
                            }
                            rawBits[bitCursor++] = if (invert) !masked else masked
                        }
                    }
                }
                upward = !upward
                rightCol -= 2
            }

            val codewords = IntArray(totalCodewords)
            for (i in 0 until totalCodewords) {
                var v = 0
                for (b in 0 until 8) {
                    v = (v shl 1) or (if (rawBits[i * 8 + b]) 1 else 0)
                }
                codewords[i] = v
            }

            val dataWords = IntArray(dataCodewordsTotal)
            if (numBlocks == 1) {
                System.arraycopy(codewords, 0, dataWords, 0, dataCodewordsTotal)
            } else {
                val blockSize = dataCodewordsTotal / 2
                for (i in 0 until blockSize) {
                    dataWords[i] = codewords[i * 2]
                    dataWords[blockSize + i] = codewords[i * 2 + 1]
                }
            }

            // Check Byte mode indicator (0100 in top 4 bits of dataWords[0])
            val mode = (dataWords[0] ushr 4) and 0x0F
            if (mode != 0b0100) continue
            val byteLen = ((dataWords[0] and 0x0F) shl 4) or ((dataWords[1] ushr 4) and 0x0F)
            if (byteLen <= 0 || byteLen + 2 > dataCodewordsTotal) continue

            val payload = ByteArray(byteLen)
            for (i in 0 until byteLen) {
                val highNibble = dataWords[i + 1] and 0x0F
                val lowNibble = (dataWords[i + 2] ushr 4) and 0x0F
                payload[i] = ((highNibble shl 4) or lowNibble).toByte()
            }
            val text = try {
                String(payload, StandardCharsets.UTF_8)
            } catch (_: Exception) {
                continue
            }
            if (text.startsWith("barq://", ignoreCase = true) ||
                text.startsWith("http://", ignoreCase = true) ||
                text.startsWith("https://", ignoreCase = true) ||
                text.contains("BRQ-", ignoreCase = true) ||
                text.all { it.code in 32..126 }
            ) {
                return text
            }
        }
        return null
    }

    /**
     * Lightweight camera Y-plane scanner that locates a bounding dark square inside the central
     * viewfinder crop and attempts to sample versions 1..6 QR matrices.
     */
    fun tryDecodeLumaFrame(yPlane: ByteArray, width: Int, height: Int, rowStride: Int): String? {
        if (width < 48 || height < 48 || yPlane.isEmpty()) return null
        val boxSize = (minOf(width, height) * 0.92f).toInt().coerceAtLeast(40)
        val startX = (width - boxSize) / 2
        val startY = (height - boxSize) / 2

        var sumLuma = 0L
        var count = 0
        for (y in startY until (startY + boxSize) step 2) {
            val rowOff = y * rowStride
            for (x in startX until (startX + boxSize) step 2) {
                val idx = rowOff + x
                if (idx in yPlane.indices) {
                    sumLuma += (yPlane[idx].toInt() and 0xFF)
                    count++
                }
            }
        }
        if (count == 0) return null
        val threshold = (sumLuma / count).toInt().coerceIn(40, 220)

        // Find exact pixel bounding box of dark modules inside the viewfinder
        var minX = startX + boxSize
        var maxX = startX - 1
        var minY = startY + boxSize
        var maxY = startY - 1
        for (y in startY until (startY + boxSize)) {
            val rowOff = y * rowStride
            for (x in startX until (startX + boxSize)) {
                val idx = rowOff + x
                if (idx in yPlane.indices && (yPlane[idx].toInt() and 0xFF) < threshold) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        val qrW = maxX - minX + 1
        val qrH = maxY - minY + 1
        if (qrW < 21 || qrH < 21) return null

        for (version in 1..6) {
            val gridSize = 17 + version * 4
            val matrix = Array(gridSize) { BooleanArray(gridSize) }
            for (r in 0 until gridSize) {
                val sampleY = (minY + ((r + 0.5f) * qrH / gridSize)).toInt().coerceIn(0, height - 1)
                val rowOff = sampleY * rowStride
                for (c in 0 until gridSize) {
                    val sampleX = (minX + ((c + 0.5f) * qrW / gridSize)).toInt().coerceIn(0, width - 1)
                    val idx = rowOff + sampleX
                    if (idx in yPlane.indices) {
                        matrix[r][c] = (yPlane[idx].toInt() and 0xFF) < threshold
                    }
                }
            }
            // Verify top-left, top-right, and bottom-left finder center dark module
            if (matrix[3][3] && matrix[3][gridSize - 4] && matrix[gridSize - 4][3]) {
                val decoded = decodeMatrix(matrix)
                if (!decoded.isNullOrBlank()) return decoded
            }
        }
        return null
    }
}
