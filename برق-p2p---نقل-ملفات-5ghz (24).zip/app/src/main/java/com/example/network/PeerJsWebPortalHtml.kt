package com.example.network

/**
 * Provides the full Arabic RTL Dark-Mode WebRTC (PeerJS) + Local 5GHz P2P Web Application for "برق sher".
 */
object PeerJsWebPortalHtml {

    fun buildHtml(defaultCode: String, hostIp: String, hostPort: Int): String = """
<!DOCTYPE html>
<html lang="ar" dir="rtl" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>برق sher - نقل الملفات عبر WebRTC و 5GHz</title>
  <script src="https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js"></script>
  <style>
    :root {
      --bg: #060B16;
      --surface: #0D1628;
      --card: #131F38;
      --border: #263B63;
      --cyan: #00E5FF;
      --emerald: #10B981;
      --amber: #F59E0B;
      --rose: #F43F5E;
      --text: #F8FAFC;
      --muted: #94A3B8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, 'Segoe UI', Tahoma, sans-serif; }
    body { background: var(--bg); color: var(--text); min-height: 100vh; padding: 16px; line-height: 1.6; display: flex; flex-direction: column; }
    .container { max-width: 680px; margin: 0 auto; width: 100%; flex: 1; }
    .banner {
      background: linear-gradient(135deg, rgba(245,158,11,0.16), rgba(0,229,255,0.08));
      border: 1px solid rgba(245,158,11,0.45);
      border-radius: 16px;
      padding: 14px 16px;
      margin-bottom: 18px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
    }
    .banner-badge {
      background: var(--amber);
      color: #1E1200;
      font-weight: 800;
      font-size: 12px;
      padding: 4px 10px;
      border-radius: 999px;
      white-space: nowrap;
    }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
    .mode-card {
      background: var(--card);
      border: 2px solid var(--border);
      border-radius: 18px;
      padding: 18px 14px;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .mode-card.active-send { border-color: var(--cyan); box-shadow: 0 0 24px rgba(0,229,255,0.18); }
    .mode-card.active-recv { border-color: var(--emerald); box-shadow: 0 0 24px rgba(16,185,129,0.18); }
    .panel {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 18px;
      margin-bottom: 16px;
    }
    .code-box {
      font-family: monospace;
      font-size: 28px;
      font-weight: 800;
      letter-spacing: 4px;
      color: var(--cyan);
      background: #081020;
      border: 1px dashed var(--cyan);
      border-radius: 14px;
      padding: 12px;
      text-align: center;
      margin: 10px 0;
    }
    .btn {
      width: 100%;
      border: none;
      border-radius: 14px;
      padding: 14px 18px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      margin-top: 10px;
      transition: opacity 0.2s;
    }
    .btn-cyan { background: var(--cyan); color: #002229; }
    .btn-emerald { background: var(--emerald); color: #002417; }
    .btn-rose { background: var(--rose); color: #fff; }
    .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text); }
    input[type="text"] {
      width: 100%;
      background: #081020;
      border: 1px solid var(--border);
      color: var(--text);
      padding: 14px;
      border-radius: 12px;
      font-size: 18px;
      text-align: center;
      font-family: monospace;
    }
    .file-item {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 12px;
      margin-top: 10px;
    }
    .progress-track {
      height: 8px;
      background: #070D19;
      border-radius: 99px;
      overflow: hidden;
      margin: 8px 0;
    }
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--cyan), var(--emerald));
      width: 0%;
      transition: width 0.15s linear;
    }
    .meta-row { display: flex; justify-content: space-between; font-size: 12px; color: var(--muted); }
    .speed-pill {
      display: inline-block;
      background: rgba(0,229,255,0.14);
      color: var(--cyan);
      font-family: monospace;
      padding: 3px 10px;
      border-radius: 99px;
      font-weight: 700;
    }
    .footer-copy {
      text-align: center;
      padding: 16px 8px;
      color: var(--muted);
      font-size: 13px;
      font-weight: 700;
      border-top: 1px solid var(--border);
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2 style="margin-bottom:12px;color:var(--cyan);">⚡ برق sher</h2>
    <div class="banner">
      <span class="banner-badge">5GHz Wi-Fi</span>
      <div style="font-size:13px;">
        <strong>خطوة التشغيل لأقصى سرعة:</strong> شغّل نقطة اتصال <b>5GHz Hotspot</b> في الجوال الأول، واتصل بها من الجوال الثاني للنقل المباشر عبر <b>WebRTC (PeerJS)</b> ودفعات <b>Chunking</b> بدون انقطاع.
      </div>
    </div>

    <div class="grid-2">
      <div id="tabSend" class="mode-card active-send" onclick="switchMode('send')">
        <div style="font-size:24px;">📤</div>
        <div style="font-weight:800;margin-top:4px;">إرسال ملفات</div>
        <div style="font-size:12px;color:var(--muted);">توليد كود + اختيار ملفات متعددة</div>
      </div>
      <div id="tabRecv" class="mode-card" onclick="switchMode('recv')">
        <div style="font-size:24px;">📥</div>
        <div style="font-weight:800;margin-top:4px;">استلام ملفات</div>
        <div style="font-size:12px;color:var(--muted);">ربط بالكود + تأكيد وتحميل مباشر</div>
      </div>
    </div>

    <div id="sendSection" class="panel">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span>كود الاتصال المباشر (PeerJS & LAN):</span>
        <span id="peerStatus" class="speed-pill">جاهز للربط</span>
      </div>
      <div id="myCodeBox" class="code-box">$defaultCode</div>
      <p style="font-size:12px;color:var(--muted);text-align:center;">
        عنوان البوابة المحلية: <code style="color:var(--cyan);">http://$hostIp:$hostPort</code>
      </p>
      <input type="file" id="fileInput" multiple style="display:none" onchange="onFilesSelected(this.files)" />
      <button class="btn btn-cyan" onclick="document.getElementById('fileInput').click()">
        + اختيار ملفات متعددة (صور، فيديو، ألعاب APK، مستندات)
      </button>
    </div>

    <div id="recvSection" class="panel" style="display:none;">
      <label style="display:block;margin-bottom:8px;font-weight:700;">أدخل كود الاتصال من الجوال المرسل:</label>
      <input type="text" id="remoteCodeInput" value="" placeholder="أدخل كود الربط مثل: 5G-4829" />
      <button class="btn btn-emerald" onclick="connectToSender()">
        ⚡ التحقق من الكود وعرض الملفات المتاحة
      </button>
      <div id="confirmBox" style="display:none;margin-top:14px;padding:14px;border:1px solid var(--emerald);border-radius:14px;background:#081526;">
        <div id="confirmSummary" style="font-size:14px;margin-bottom:10px;"></div>
        <button class="btn btn-emerald" onclick="confirmAndStartDownload()">تأكيد وبدء استلام الملفات</button>
        <button class="btn btn-rose" onclick="cancelDownloadConfirmation()">إلغاء</button>
      </div>
    </div>

    <div class="panel">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong>شاشة النقل الحية (Chunking)</strong>
        <span id="liveSpeedBadge" class="speed-pill">0.0 MB/s</span>
      </div>
      <div id="transferList">
        <div style="text-align:center;color:var(--muted);padding:18px;font-size:13px;">
          لا توجد ملفات قيد النقل حالياً. اختر ملفات أو اتصل بالجوال المرسل للبدء.
        </div>
      </div>
    </div>

    <div class="footer-copy">جميع الحقوق محفوظة © saeed</div>
  </div>

  <script>
    const CHUNK_SIZE = 4 * 1024 * 1024;
    let currentMode = 'send';
    let selectedFiles = [];
    let pendingManifestFiles = [];
    let verifiedCode = '';
    const myShortCode = "$defaultCode";

    function switchMode(mode) {
      currentMode = mode;
      document.getElementById('sendSection').style.display = mode === 'send' ? 'block' : 'none';
      document.getElementById('recvSection').style.display = mode === 'recv' ? 'block' : 'none';
      document.getElementById('tabSend').className = 'mode-card ' + (mode === 'send' ? 'active-send' : '');
      document.getElementById('tabRecv').className = 'mode-card ' + (mode === 'recv' ? 'active-recv' : '');
    }

    function formatSize(bytes) {
      if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
      if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
      return (bytes / 1024).toFixed(1) + ' KB';
    }

    function onFilesSelected(fileList) {
      selectedFiles = Array.from(fileList);
      if (!selectedFiles.length) {
        alert('الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال');
        return;
      }
      renderFiles(selectedFiles.map((f, i) => ({
        id: 'local-' + i,
        name: f.name,
        sizeBytes: f.size,
        progress: 0,
        chunks: Math.max(1, Math.ceil(f.size / CHUNK_SIZE)),
        doneChunks: 0,
        speed: 'جاهز للإرسال'
      })));
    }

    async function connectToSender() {
      const code = document.getElementById('remoteCodeInput').value.trim();
      if (!code) {
        alert('فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد');
        return;
      }
      try {
        const res = await fetch('/api/manifest?code=' + encodeURIComponent(code));
        if (!res.ok) {
          alert('فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد');
          return;
        }
        const data = await res.json();
        if (!data.files || !data.files.length) {
          alert('فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد');
          return;
        }
        pendingManifestFiles = data.files;
        verifiedCode = code;
        const totalSize = pendingManifestFiles.reduce((acc, f) => acc + (f.sizeBytes || 0), 0);
        document.getElementById('confirmSummary').innerHTML =
          '<strong>ملفات واردة من المرسل (' + pendingManifestFiles.length + ' ملفات • الإجمالي ' + formatSize(totalSize) + '):</strong><br/>' +
          pendingManifestFiles.map(f => '• ' + f.name + ' (' + formatSize(f.sizeBytes) + ')').join('<br/>');
        document.getElementById('confirmBox').style.display = 'block';
      } catch (e) {
        alert('فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد');
      }
    }

    function cancelDownloadConfirmation() {
      pendingManifestFiles = [];
      verifiedCode = '';
      document.getElementById('confirmBox').style.display = 'none';
    }

    async function confirmAndStartDownload() {
      document.getElementById('confirmBox').style.display = 'none';
      if (!pendingManifestFiles.length || !verifiedCode) return;
      await downloadFilesChunkedFromHost(pendingManifestFiles, verifiedCode);
    }

    async function downloadFilesChunkedFromHost(files, code) {
      const uiItems = files.map(f => ({
        id: f.id,
        name: f.name,
        sizeBytes: f.sizeBytes,
        progress: 0,
        chunks: f.totalChunks,
        doneChunks: 0,
        speed: '0.0 MB/s',
        downloadUrl: null
      }));
      renderFiles(uiItems);

      for (let idx = 0; idx < files.length; idx++) {
        const f = files[idx];
        const parts = [];
        const startTime = performance.now();
        let receivedBytes = 0;

        for (let c = 0; c < f.totalChunks; c++) {
          const resp = await fetch('/api/chunk?fileId=' + encodeURIComponent(f.id) + '&chunkIndex=' + c + '&code=' + encodeURIComponent(code));
          if (!resp.ok) throw new Error('Chunk transfer failed');
          const buf = await resp.arrayBuffer();
          parts.push(buf);
          receivedBytes += buf.byteLength;
          const elapsedSec = Math.max(0.05, (performance.now() - startTime) / 1000);
          const mbps = (receivedBytes / (1024 * 1024)) / elapsedSec;
          uiItems[idx].doneChunks = c + 1;
          uiItems[idx].progress = Math.min(100, Math.round((receivedBytes / Math.max(1, f.sizeBytes)) * 100));
          uiItems[idx].speed = mbps.toFixed(1) + ' MB/s';
          document.getElementById('liveSpeedBadge').innerText = uiItems[idx].speed;
          renderFiles(uiItems);
        }

        const blob = new Blob(parts, { type: 'application/octet-stream' });
        uiItems[idx].downloadUrl = URL.createObjectURL(blob);
        renderFiles(uiItems);

        const a = document.createElement('a');
        a.href = uiItems[idx].downloadUrl;
        a.download = f.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    }

    function renderFiles(items) {
      const container = document.getElementById('transferList');
      if (!items.length) return;
      container.innerHTML = items.map(item => `
        <div class="file-item">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <strong style="font-size:14px;">${'$'}{item.name}</strong>
            <span class="speed-pill">${'$'}{item.speed}</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width:${'$'}{item.progress}%"></div>
          </div>
          <div class="meta-row">
            <span>الحجم: ${'$'}{formatSize(item.sizeBytes)}</span>
            <span>الدفعات: ${'$'}{item.doneChunks} / ${'$'}{item.chunks} (${'$'}{item.progress}%)</span>
          </div>
        </div>
      `).join('');
    }
  </script>
</body>
</html>
    """.trimIndent()
}
