package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

    LaunchedEffect(context) {
        BarqThemeState.ensureInitialized(context)
    }

    val targetPalette = BarqThemeState.resolvePalette(systemInDarkTheme = systemDark)
    val animSpec = tween<Color>(durationMillis = 260)

    val animBg by animateColorAsState(targetPalette.background, animSpec, label = "theme_bg")
    val animSurface by animateColorAsState(targetPalette.surface, animSpec, label = "theme_surface")
    val animCard by animateColorAsState(targetPalette.card, animSpec, label = "theme_card")
    val animCardElevated by animateColorAsState(targetPalette.cardElevated, animSpec, label = "theme_card_elev")
    val animBorder by animateColorAsState(targetPalette.border, animSpec, label = "theme_border")
    val animPrimary by animateColorAsState(targetPalette.primaryAccent, animSpec, label = "theme_primary")
    val animPrimaryDim by animateColorAsState(targetPalette.primaryAccentDim, animSpec, label = "theme_primary_dim")
    val animSecondary by animateColorAsState(targetPalette.secondaryAccent, animSpec, label = "theme_secondary")
    val animSecondaryDim by animateColorAsState(targetPalette.secondaryAccentDim, animSpec, label = "theme_secondary_dim")
    val animTertiary by animateColorAsState(targetPalette.tertiaryAccent, animSpec, label = "theme_tertiary")
    val animTertiarySoft by animateColorAsState(targetPalette.tertiarySoft, animSpec, label = "theme_tertiary_soft")
    val animDanger by animateColorAsState(targetPalette.dangerAccent, animSpec, label = "theme_danger")
    val animHighlight by animateColorAsState(targetPalette.highlightAccent, animSpec, label = "theme_highlight")
    val animTextPrimary by animateColorAsState(targetPalette.textPrimary, animSpec, label = "theme_text_primary")
    val animTextSecondary by animateColorAsState(targetPalette.textSecondary, animSpec, label = "theme_text_secondary")
    val animTextMuted by animateColorAsState(targetPalette.textMuted, animSpec, label = "theme_text_muted")

    val animatedPalette = targetPalette.copy(
        background = animBg,
        surface = animSurface,
        card = animCard,
        cardElevated = animCardElevated,
        border = animBorder,
        primaryAccent = animPrimary,
        primaryAccentDim = animPrimaryDim,
        secondaryAccent = animSecondary,
        secondaryAccentDim = animSecondaryDim,
        tertiaryAccent = animTertiary,
        tertiarySoft = animTertiarySoft,
        dangerAccent = animDanger,
        highlightAccent = animHighlight,
        textPrimary = animTextPrimary,
        textSecondary = animTextSecondary,
        textMuted = animTextMuted
    )
    BarqThemeState.activePalette = animatedPalette

    val colorScheme = if (targetPalette.isLight) {
        lightColorScheme(
            primary = animPrimary,
            onPrimary = highContrastTextFor(animPrimary),
            primaryContainer = animCardElevated,
            onPrimaryContainer = animTextPrimary,
            secondary = animSecondary,
            onSecondary = highContrastTextFor(animSecondary),
            secondaryContainer = animCardElevated,
            onSecondaryContainer = animTextPrimary,
            tertiary = animTertiary,
            onTertiary = highContrastTextFor(animTertiary),
            tertiaryContainer = animTertiarySoft,
            onTertiaryContainer = animTextPrimary,
            background = animBg,
            onBackground = animTextPrimary,
            surface = animSurface,
            onSurface = animTextPrimary,
            surfaceVariant = animCard,
            onSurfaceVariant = animTextSecondary,
            outline = animBorder,
            error = animDanger,
            onError = Color.White
        )
    } else {
        darkColorScheme(
            primary = animPrimary,
            onPrimary = highContrastTextFor(animPrimary),
            primaryContainer = animCardElevated,
            onPrimaryContainer = animTextPrimary,
            secondary = animSecondary,
            onSecondary = highContrastTextFor(animSecondary),
            secondaryContainer = animCardElevated,
            onSecondaryContainer = animTextPrimary,
            tertiary = animTertiary,
            onTertiary = highContrastTextFor(animTertiary),
            tertiaryContainer = animTertiarySoft,
            onTertiaryContainer = animTextPrimary,
            background = animBg,
            onBackground = animTextPrimary,
            surface = animSurface,
            onSurface = animTextPrimary,
            surfaceVariant = animCard,
            onSurfaceVariant = animTextSecondary,
            outline = animBorder,
            error = animDanger,
            onError = Color.White
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides BarqThemeState.layoutDirection) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content
        )
    }
}
