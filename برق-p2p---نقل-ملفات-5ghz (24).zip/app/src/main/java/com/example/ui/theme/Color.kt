package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.max
import kotlin.math.min

enum class BarqThemeId(
    val storageKey: String,
    val englishTitle: String,
    val arabicTitle: String,
    val subtitle: String,
    val isLightByDefault: Boolean = false
) {
    MIDNIGHT_BLUE(
        storageKey = "MIDNIGHT_BLUE",
        englishTitle = "Midnight Blue",
        arabicTitle = "أزرق منتصف الليل (الافتراضي)",
        subtitle = "هوية برق الأصلية بخلفية ليلية عميقة وتوهج السيان والزمرد"
    ),
    CYBERPUNK(
        storageKey = "CYBERPUNK",
        englishTitle = "Cyberpunk",
        arabicTitle = "سايبربانك نيون",
        subtitle = "أرجواني ليلي مشبع مع فوشيا نيون وأصفر كهربائي عالي التباين"
    ),
    PURE_LIGHT(
        storageKey = "PURE_LIGHT",
        englishTitle = "Pure Light",
        arabicTitle = "نهاري نقي (Pure Light)",
        subtitle = "واجهة فاتحة نقية بنصوص داكنة فائقة الوضوح تحت أشعة الشمس",
        isLightByDefault = true
    ),
    EMERALD(
        storageKey = "EMERALD",
        englishTitle = "Emerald",
        arabicTitle = "الزمرد الملكي",
        subtitle = "أخضر زمردي عميق مريح للعين مع لمسات نعناعية وذهبية"
    ),
    LUXURY_GOLD(
        storageKey = "LUXURY_GOLD",
        englishTitle = "Luxury Gold",
        arabicTitle = "الذهب الفاخر",
        subtitle = "أسود أونيكس ملكي مع تدرجات الذهب الخالص والكهرمان الدافئ"
    ),
    GLASSMORPHISM(
        storageKey = "GLASSMORPHISM",
        englishTitle = "Glassmorphism",
        arabicTitle = "بلوري زجاجي (Glass)",
        subtitle = "أسطح زجاجية ثلجية شفافة مع حدود سماوية مضيئة"
    ),
    CRIMSON(
        storageKey = "CRIMSON",
        englishTitle = "Crimson",
        arabicTitle = "القرمزي الناري",
        subtitle = "أحمر قرمزي داكن مع توهج ياقوتي وبرتقالي نابض"
    ),
    GRAPHITE(
        storageKey = "GRAPHITE",
        englishTitle = "Graphite",
        arabicTitle = "الجرافيت المعدني",
        subtitle = "رمادي تيتانيوم هندسي مع أزرق فولاذي هادئ وتباين متوازن"
    ),
    CUSTOM(
        storageKey = "CUSTOM",
        englishTitle = "Custom",
        arabicTitle = "مخصص (لوحة ألوان كاملة)",
        subtitle = "تصميم لوني حر بالكامل من لوحة الألوان مع ضمان وضوح النصوص"
    );

    companion object {
        fun fromKey(key: String?): BarqThemeId {
            return entries.find { it.storageKey.equals(key, ignoreCase = true) } ?: MIDNIGHT_BLUE
        }
    }
}

@Immutable
data class BarqThemePalette(
    val themeId: BarqThemeId,
    val background: Color,
    val surface: Color,
    val card: Color,
    val cardElevated: Color,
    val border: Color,
    val primaryAccent: Color,
    val primaryAccentDim: Color,
    val secondaryAccent: Color,
    val secondaryAccentDim: Color,
    val tertiaryAccent: Color,
    val tertiarySoft: Color,
    val dangerAccent: Color,
    val highlightAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val isLight: Boolean
) {
    val onPrimaryAccent: Color
        get() = highContrastTextFor(primaryAccent)

    val onSecondaryAccent: Color
        get() = highContrastTextFor(secondaryAccent)

    val onTertiaryAccent: Color
        get() = highContrastTextFor(tertiaryAccent)

    val contrastRatioPrimaryText: Double
        get() = calculateContrastRatio(textPrimary, card)
}

fun highContrastTextFor(backgroundColor: Color): Color {
    val darkCandidate = Color(0xFF050A12)
    val lightCandidate = Color(0xFFFFFFFF)
    val darkContrast = calculateContrastRatio(darkCandidate, backgroundColor)
    val lightContrast = calculateContrastRatio(lightCandidate, backgroundColor)
    return if (darkContrast >= lightContrast) {
        if (darkContrast >= 4.5) darkCandidate else Color(0xFF000000)
    } else {
        lightCandidate
    }
}

fun calculateContrastRatio(foreground: Color, background: Color): Double {
    val l1 = foreground.luminance().toDouble()
    val l2 = background.luminance().toDouble()
    val brightest = max(l1, l2)
    val darkest = min(l1, l2)
    return (brightest + 0.05) / (darkest + 0.05)
}

private fun shiftColorBrightness(color: Color, factor: Float): Color {
    val r = (color.red * factor).coerceIn(0f, 1f)
    val g = (color.green * factor).coerceIn(0f, 1f)
    val b = (color.blue * factor).coerceIn(0f, 1f)
    return Color(r, g, b, 1f)
}

private fun blendColors(c1: Color, c2: Color, ratioC2: Float): Color {
    val rRatio = ratioC2.coerceIn(0f, 1f)
    val inv = 1f - rRatio
    return Color(
        red = (c1.red * inv + c2.red * rRatio).coerceIn(0f, 1f),
        green = (c1.green * inv + c2.green * rRatio).coerceIn(0f, 1f),
        blue = (c1.blue * inv + c2.blue * rRatio).coerceIn(0f, 1f),
        alpha = 1f
    )
}

object BarqThemePalettes {
    val MidnightBlue = BarqThemePalette(
        themeId = BarqThemeId.MIDNIGHT_BLUE,
        background = Color(0xFF060B16),
        surface = Color(0xFF0D1628),
        card = Color(0xFF131F38),
        cardElevated = Color(0xFF1A2A4A),
        border = Color(0xFF263B63),
        primaryAccent = Color(0xFF00E5FF),
        primaryAccentDim = Color(0xFF0088A3),
        secondaryAccent = Color(0xFF10B981),
        secondaryAccentDim = Color(0xFF056C4B),
        tertiaryAccent = Color(0xFFF59E0B),
        tertiarySoft = Color(0xFF3B2A10),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF8B5CF6),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFF94A3B8),
        textMuted = Color(0xFF64748B),
        isLight = false
    )

    val Cyberpunk = BarqThemePalette(
        themeId = BarqThemeId.CYBERPUNK,
        background = Color(0xFF090414),
        surface = Color(0xFF130926),
        card = Color(0xFF1D0E38),
        cardElevated = Color(0xFF2A1550),
        border = Color(0xFF5B21B6),
        primaryAccent = Color(0xFFFF2A85),
        primaryAccentDim = Color(0xFFBE185D),
        secondaryAccent = Color(0xFF00F0FF),
        secondaryAccentDim = Color(0xFF0891B2),
        tertiaryAccent = Color(0xFFFCEE09),
        tertiarySoft = Color(0xFF3B3506),
        dangerAccent = Color(0xFFFF4D6D),
        highlightAccent = Color(0xFFA855F7),
        textPrimary = Color(0xFFFDF4FF),
        textSecondary = Color(0xFFD8B4FE),
        textMuted = Color(0xFFA78BFA),
        isLight = false
    )

    val PureLight = BarqThemePalette(
        themeId = BarqThemeId.PURE_LIGHT,
        background = Color(0xFFF1F5F9),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFFFFFFF),
        cardElevated = Color(0xFFE2E8F0),
        border = Color(0xFFCBD5E1),
        primaryAccent = Color(0xFF0284C7),
        primaryAccentDim = Color(0xFF0369A1),
        secondaryAccent = Color(0xFF059669),
        secondaryAccentDim = Color(0xFF047857),
        tertiaryAccent = Color(0xFFD97706),
        tertiarySoft = Color(0xFFFEF3C7),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFF7C3AED),
        textPrimary = Color(0xFF0F172A),
        textSecondary = Color(0xFF334155),
        textMuted = Color(0xFF64748B),
        isLight = true
    )

    val Emerald = BarqThemePalette(
        themeId = BarqThemeId.EMERALD,
        background = Color(0xFF031410),
        surface = Color(0xFF07221B),
        card = Color(0xFF0C3027),
        cardElevated = Color(0xFF134236),
        border = Color(0xFF1E5E4D),
        primaryAccent = Color(0xFF10B981),
        primaryAccentDim = Color(0xFF059669),
        secondaryAccent = Color(0xFF34D399),
        secondaryAccentDim = Color(0xFF047857),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF3A2C0A),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF2DD4BF),
        textPrimary = Color(0xFFECFDF5),
        textSecondary = Color(0xFFA7F3D0),
        textMuted = Color(0xFF6EE7B7),
        isLight = false
    )

    val LuxuryGold = BarqThemePalette(
        themeId = BarqThemeId.LUXURY_GOLD,
        background = Color(0xFF0C0A06),
        surface = Color(0xFF17130B),
        card = Color(0xFF221C11),
        cardElevated = Color(0xFF302718),
        border = Color(0xFF5C4822),
        primaryAccent = Color(0xFFF59E0B),
        primaryAccentDim = Color(0xFFB45309),
        secondaryAccent = Color(0xFFFBBF24),
        secondaryAccentDim = Color(0xFF92400E),
        tertiaryAccent = Color(0xFFEAB308),
        tertiarySoft = Color(0xFF3B2E0D),
        dangerAccent = Color(0xFFEF4444),
        highlightAccent = Color(0xFFFDE047),
        textPrimary = Color(0xFFFFFBEB),
        textSecondary = Color(0xFFFDE68A),
        textMuted = Color(0xFFD97706),
        isLight = false
    )

    val Glassmorphism = BarqThemePalette(
        themeId = BarqThemeId.GLASSMORPHISM,
        background = Color(0xFF081426),
        surface = Color(0xFF102340),
        card = Color(0xFF173156),
        cardElevated = Color(0xFF204170),
        border = Color(0xFF38BDF8),
        primaryAccent = Color(0xFF38BDF8),
        primaryAccentDim = Color(0xFF0284C7),
        secondaryAccent = Color(0xFF2DD4BF),
        secondaryAccentDim = Color(0xFF0D9488),
        tertiaryAccent = Color(0xFFF472B6),
        tertiarySoft = Color(0xFF3B152B),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFF818CF8),
        textPrimary = Color(0xFFF0F9FF),
        textSecondary = Color(0xFFBAE6FD),
        textMuted = Color(0xFF7DD3FC),
        isLight = false
    )

    val Crimson = BarqThemePalette(
        themeId = BarqThemeId.CRIMSON,
        background = Color(0xFF140609),
        surface = Color(0xFF240B11),
        card = Color(0xFF331019),
        cardElevated = Color(0xFF471623),
        border = Color(0xFF881337),
        primaryAccent = Color(0xFFF43F5E),
        primaryAccentDim = Color(0xFFBE123C),
        secondaryAccent = Color(0xFFFB923C),
        secondaryAccentDim = Color(0xFFC2410C),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF3E2408),
        dangerAccent = Color(0xFFFF2E4C),
        highlightAccent = Color(0xFFE879F9),
        textPrimary = Color(0xFFFFF1F2),
        textSecondary = Color(0xFFFECDD3),
        textMuted = Color(0xFFFDA4AF),
        isLight = false
    )

    val Graphite = BarqThemePalette(
        themeId = BarqThemeId.GRAPHITE,
        background = Color(0xFF0F1115),
        surface = Color(0xFF181B22),
        card = Color(0xFF222630),
        cardElevated = Color(0xFF2D3240),
        border = Color(0xFF3F4759),
        primaryAccent = Color(0xFF60A5FA),
        primaryAccentDim = Color(0xFF2563EB),
        secondaryAccent = Color(0xFF34D399),
        secondaryAccentDim = Color(0xFF059669),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF362A10),
        dangerAccent = Color(0xFFF87171),
        highlightAccent = Color(0xFFA78BFA),
        textPrimary = Color(0xFFF9FAFB),
        textSecondary = Color(0xFFD1D5DB),
        textMuted = Color(0xFF9CA3AF),
        isLight = false
    )

    fun buildCustomPalette(
        primaryColor: Color,
        secondaryColor: Color,
        backgroundColor: Color,
        isLightMode: Boolean
    ): BarqThemePalette {
        val safeBg = if (isLightMode && backgroundColor.luminance() < 0.55f) {
            Color(0xFFF8FAFC)
        } else if (!isLightMode && backgroundColor.luminance() > 0.45f) {
            Color(0xFF0B101B)
        } else {
            backgroundColor
        }
        val surface = if (isLightMode) {
            Color(0xFFFFFFFF)
        } else {
            blendColors(safeBg, Color.White, 0.06f)
        }
        val card = if (isLightMode) {
            Color(0xFFFFFFFF)
        } else {
            blendColors(safeBg, primaryColor, 0.12f)
        }
        val cardElevated = if (isLightMode) {
            blendColors(Color(0xFFF1F5F9), primaryColor, 0.08f)
        } else {
            blendColors(card, Color.White, 0.08f)
        }
        val border = if (isLightMode) {
            blendColors(Color(0xFFCBD5E1), primaryColor, 0.28f)
        } else {
            blendColors(cardElevated, primaryColor, 0.38f)
        }
        val textPrimary = if (isLightMode) Color(0xFF0F172A) else Color(0xFFF8FAFC)
        val textSecondary = if (isLightMode) Color(0xFF334155) else Color(0xFFCBD5E1)
        val textMuted = if (isLightMode) Color(0xFF64748B) else Color(0xFF94A3B8)

        return BarqThemePalette(
            themeId = BarqThemeId.CUSTOM,
            background = safeBg,
            surface = surface,
            card = card,
            cardElevated = cardElevated,
            border = border,
            primaryAccent = primaryColor,
            primaryAccentDim = shiftColorBrightness(primaryColor, 0.75f),
            secondaryAccent = secondaryColor,
            secondaryAccentDim = shiftColorBrightness(secondaryColor, 0.75f),
            tertiaryAccent = Color(0xFFF59E0B),
            tertiarySoft = if (isLightMode) Color(0xFFFEF3C7) else Color(0xFF3B2A10),
            dangerAccent = if (isLightMode) Color(0xFFE11D48) else Color(0xFFF43F5E),
            highlightAccent = blendColors(primaryColor, secondaryColor, 0.5f),
            textPrimary = textPrimary,
            textSecondary = textSecondary,
            textMuted = textMuted,
            isLight = isLightMode
        )
    }

    fun forThemeId(
        themeId: BarqThemeId,
        customPrimary: Color = Color(0xFF38BDF8),
        customSecondary: Color = Color(0xFF10B981),
        customBackground: Color = Color(0xFF081020),
        customIsLight: Boolean = false
    ): BarqThemePalette {
        return when (themeId) {
            BarqThemeId.MIDNIGHT_BLUE -> MidnightBlue
            BarqThemeId.CYBERPUNK -> Cyberpunk
            BarqThemeId.PURE_LIGHT -> PureLight
            BarqThemeId.EMERALD -> Emerald
            BarqThemeId.LUXURY_GOLD -> LuxuryGold
            BarqThemeId.GLASSMORPHISM -> Glassmorphism
            BarqThemeId.CRIMSON -> Crimson
            BarqThemeId.GRAPHITE -> Graphite
            BarqThemeId.CUSTOM -> buildCustomPalette(
                primaryColor = customPrimary,
                secondaryColor = customSecondary,
                backgroundColor = customBackground,
                isLightMode = customIsLight
            )
        }
    }
}

/**
 * Global reactive theme state manager backed by SharedPreferences ("barq_theme_prefs")
 * so theme choices, custom colors, auto light/dark mode, and layout direction persist
 * across app restarts without touching P2P transfer or File Manager threads.
 */
object BarqThemeState {
    private const val PREFS_NAME = "barq_theme_prefs"
    private const val KEY_THEME_ID = "selected_theme_id"
    private const val KEY_AUTO_SYSTEM = "auto_system_mode"
    private const val KEY_CUSTOM_PRIMARY = "custom_primary_argb"
    private const val KEY_CUSTOM_SECONDARY = "custom_secondary_argb"
    private const val KEY_CUSTOM_BG = "custom_bg_argb"
    private const val KEY_CUSTOM_IS_LIGHT = "custom_is_light"
    private const val KEY_LAYOUT_DIRECTION = "layout_direction_mode"

    var selectedThemeId by mutableStateOf(BarqThemeId.MIDNIGHT_BLUE)
        private set

    var autoSystemDarkLightMode by mutableStateOf(false)
        private set

    var customPrimaryColor by mutableStateOf(Color(0xFF38BDF8))
        private set

    var customSecondaryColor by mutableStateOf(Color(0xFF10B981))
        private set

    var customBackgroundColor by mutableStateOf(Color(0xFF081020))
        private set

    var customIsLight by mutableStateOf(false)
        private set

    var layoutDirection by mutableStateOf(LayoutDirection.Rtl)
        private set

    var activePalette by mutableStateOf(BarqThemePalettes.MidnightBlue)
        internal set

    private var isInitializedFromPrefs = false

    fun ensureInitialized(context: Context) {
        if (!isInitializedFromPrefs) {
            loadFromPreferences(context)
        }
    }

    fun loadFromPreferences(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedId = BarqThemeId.fromKey(prefs.getString(KEY_THEME_ID, BarqThemeId.MIDNIGHT_BLUE.storageKey))
            val autoMode = prefs.getBoolean(KEY_AUTO_SYSTEM, false)
            val cPrim = Color(prefs.getInt(KEY_CUSTOM_PRIMARY, Color(0xFF38BDF8).toArgb()))
            val cSec = Color(prefs.getInt(KEY_CUSTOM_SECONDARY, Color(0xFF10B981).toArgb()))
            val cBg = Color(prefs.getInt(KEY_CUSTOM_BG, Color(0xFF081020).toArgb()))
            val cLight = prefs.getBoolean(KEY_CUSTOM_IS_LIGHT, false)
            val dirStr = prefs.getString(KEY_LAYOUT_DIRECTION, "RTL") ?: "RTL"

            selectedThemeId = savedId
            autoSystemDarkLightMode = autoMode
            customPrimaryColor = cPrim
            customSecondaryColor = cSec
            customBackgroundColor = cBg
            customIsLight = cLight
            layoutDirection = if (dirStr.equals("LTR", ignoreCase = true)) LayoutDirection.Ltr else LayoutDirection.Rtl
            activePalette = resolvePalette(systemInDarkTheme = true)
            isInitializedFromPrefs = true
        } catch (_: Exception) {
        }
    }

    fun resolvePalette(systemInDarkTheme: Boolean): BarqThemePalette {
        if (autoSystemDarkLightMode) {
            return if (systemInDarkTheme) {
                val darkChoice = if (selectedThemeId == BarqThemeId.PURE_LIGHT) {
                    BarqThemeId.MIDNIGHT_BLUE
                } else {
                    selectedThemeId
                }
                BarqThemePalettes.forThemeId(
                    themeId = darkChoice,
                    customPrimary = customPrimaryColor,
                    customSecondary = customSecondaryColor,
                    customBackground = customBackgroundColor,
                    customIsLight = false
                )
            } else {
                BarqThemePalettes.PureLight
            }
        }
        return BarqThemePalettes.forThemeId(
            themeId = selectedThemeId,
            customPrimary = customPrimaryColor,
            customSecondary = customSecondaryColor,
            customBackground = customBackgroundColor,
            customIsLight = customIsLight
        )
    }

    fun applyTheme(context: Context, themeId: BarqThemeId, disableAutoMode: Boolean = true) {
        selectedThemeId = themeId
        if (disableAutoMode) {
            autoSystemDarkLightMode = false
        }
        activePalette = BarqThemePalettes.forThemeId(
            themeId = themeId,
            customPrimary = customPrimaryColor,
            customSecondary = customSecondaryColor,
            customBackground = customBackgroundColor,
            customIsLight = customIsLight
        )
        saveToPreferences(context)
    }

    fun setAutoSystemMode(context: Context, enabled: Boolean, isSystemDarkNow: Boolean = true) {
        autoSystemDarkLightMode = enabled
        activePalette = resolvePalette(isSystemDarkNow)
        saveToPreferences(context)
    }

    fun updateCustomTheme(
        context: Context,
        primary: Color = customPrimaryColor,
        secondary: Color = customSecondaryColor,
        background: Color = customBackgroundColor,
        isLight: Boolean = customIsLight,
        applyImmediately: Boolean = true
    ) {
        customPrimaryColor = primary
        customSecondaryColor = secondary
        customBackgroundColor = background
        customIsLight = isLight
        if (applyImmediately) {
            selectedThemeId = BarqThemeId.CUSTOM
            autoSystemDarkLightMode = false
            activePalette = BarqThemePalettes.buildCustomPalette(
                primaryColor = primary,
                secondaryColor = secondary,
                backgroundColor = background,
                isLightMode = isLight
            )
        }
        saveToPreferences(context)
    }

    fun resetToDefaultTheme(context: Context) {
        selectedThemeId = BarqThemeId.MIDNIGHT_BLUE
        autoSystemDarkLightMode = false
        customPrimaryColor = Color(0xFF38BDF8)
        customSecondaryColor = Color(0xFF10B981)
        customBackgroundColor = Color(0xFF081020)
        customIsLight = false
        activePalette = BarqThemePalettes.MidnightBlue
        saveToPreferences(context)
    }

    fun setLayoutDirectionMode(context: Context, direction: LayoutDirection) {
        layoutDirection = direction
        saveToPreferences(context)
    }

    private fun saveToPreferences(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_THEME_ID, selectedThemeId.storageKey)
                .putBoolean(KEY_AUTO_SYSTEM, autoSystemDarkLightMode)
                .putInt(KEY_CUSTOM_PRIMARY, customPrimaryColor.toArgb())
                .putInt(KEY_CUSTOM_SECONDARY, customSecondaryColor.toArgb())
                .putInt(KEY_CUSTOM_BG, customBackgroundColor.toArgb())
                .putBoolean(KEY_CUSTOM_IS_LIGHT, customIsLight)
                .putString(KEY_LAYOUT_DIRECTION, if (layoutDirection == LayoutDirection.Ltr) "LTR" else "RTL")
                .apply()
            isInitializedFromPrefs = true
        } catch (_: Exception) {
        }
    }
}

// Reactive Palette Tokens used across all Barq P2P screens & components
val MidnightBg: Color
    get() = BarqThemeState.activePalette.background

val MidnightSurface: Color
    get() = BarqThemeState.activePalette.surface

val MidnightCard: Color
    get() = BarqThemeState.activePalette.card

val MidnightCardElevated: Color
    get() = BarqThemeState.activePalette.cardElevated

val GlassBorder: Color
    get() = BarqThemeState.activePalette.border

// Accents
val ElectricCyan: Color
    get() = BarqThemeState.activePalette.primaryAccent

val ElectricCyanDim: Color
    get() = BarqThemeState.activePalette.primaryAccentDim

val NeonEmerald: Color
    get() = BarqThemeState.activePalette.secondaryAccent

val NeonEmeraldDim: Color
    get() = BarqThemeState.activePalette.secondaryAccentDim

val HotspotAmber: Color
    get() = BarqThemeState.activePalette.tertiaryAccent

val HotspotAmberSoft: Color
    get() = BarqThemeState.activePalette.tertiarySoft

val CoralRose: Color
    get() = BarqThemeState.activePalette.dangerAccent

val RoyalViolet: Color
    get() = BarqThemeState.activePalette.highlightAccent

// Text Colors
val TextPrimary: Color
    get() = BarqThemeState.activePalette.textPrimary

val TextSecondary: Color
    get() = BarqThemeState.activePalette.textSecondary

val TextMuted: Color
    get() = BarqThemeState.activePalette.textMuted

val OnPrimaryAccent: Color
    get() = BarqThemeState.activePalette.onPrimaryAccent

val OnSecondaryAccent: Color
    get() = BarqThemeState.activePalette.onSecondaryAccent

val OnTertiaryAccent: Color
    get() = BarqThemeState.activePalette.onTertiaryAccent
